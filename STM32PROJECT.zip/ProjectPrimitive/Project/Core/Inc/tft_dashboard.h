#ifndef TFT_DASHBOARD_H
#define TFT_DASHBOARD_H

#include "stm32f1xx_hal.h"

// Dışarıya açtığımız (main.c'den çağrılacak) fonksiyonlar
void Dashboard_Init(void);
void Dashboard_UpdateValues(float current, float min, float max, float avg);
void Dashboard_ShowAlarm(void);
void Dashboard_ClearAlarm(void);

#endif /* TFT_DASHBOARD_H */
