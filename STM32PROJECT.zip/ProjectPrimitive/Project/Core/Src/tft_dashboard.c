#include "tft_dashboard.h"
#include <stdio.h>
#include <string.h>

// --- EKSİK OLAN PİN TANIMLAMALARI (Burası eklenecek) ---
#define TFT_DATA_PORT   GPIOE
#define TFT_RST_PORT    GPIOE
#define TFT_RST_PIN     GPIO_PIN_8
#define TFT_RD_PORT     GPIOE
#define TFT_RD_PIN      GPIO_PIN_10
#define TFT_WR_PORT     GPIOE
#define TFT_WR_PIN      GPIO_PIN_11
#define TFT_RS_PORT     GPIOE
#define TFT_RS_PIN      GPIO_PIN_12
#define TFT_CS_PORT     GPIOE
#define TFT_CS_PIN      GPIO_PIN_15
// --------------------------------------------------------
// RGB565 Renk Tanımlamaları
#define TFT_BLACK       0x0000
#define TFT_WHITE       0xFFFF
#define TFT_RED         0xF800
#define TFT_GREEN       0x07E0
#define TFT_BLUE        0x001F
#define TFT_YELLOW      0xFFE0
#define TFT_BG_COLOR    0x18E3 // Koyu mavi/lacivert hoş bir arka plan rengi

// ASCII 32'den (Boşluk) başlayan standart 5x7 Font Haritası (Sadece ihtiyacımız olan karakterler)
static const uint8_t font5x7[][5] = {
    {0x00, 0x00, 0x00, 0x00, 0x00}, // Space
    {0x00, 0x00, 0x4f, 0x00, 0x00}, // !
    {0x00, 0x07, 0x00, 0x07, 0x00}, // "
    {0x14, 0x7f, 0x14, 0x7f, 0x14}, // #
    {0x24, 0x2a, 0x7f, 0x2a, 0x12}, // $
    {0x23, 0x13, 0x08, 0x64, 0x62}, // %
    {0x36, 0x49, 0x55, 0x22, 0x50}, // &
    {0x00, 0x05, 0x03, 0x00, 0x00}, // '
    {0x00, 0x1c, 0x22, 0x41, 0x00}, // (
    {0x00, 0x41, 0x22, 0x1c, 0x00}, // )
    {0x14, 0x08, 0x3e, 0x08, 0x14}, // *
    {0x08, 0x08, 0x3e, 0x08, 0x08}, // +
    {0x00, 0x50, 0x30, 0x00, 0x00}, // ,
    {0x08, 0x08, 0x08, 0x08, 0x08}, // -
    {0x00, 0x60, 0x60, 0x00, 0x00}, // .
    {0x20, 0x10, 0x08, 0x04, 0x02}, // /
    {0x3e, 0x51, 0x49, 0x45, 0x3e}, // 0
    {0x00, 0x42, 0x7f, 0x40, 0x00}, // 1
    {0x42, 0x61, 0x51, 0x49, 0x46}, // 2
    {0x21, 0x41, 0x45, 0x4b, 0x31}, // 3
    {0x18, 0x14, 0x12, 0x7f, 0x10}, // 4
    {0x27, 0x45, 0x45, 0x45, 0x39}, // 5
    {0x3c, 0x4a, 0x49, 0x49, 0x30}, // 6
    {0x01, 0x71, 0x09, 0x05, 0x03}, // 7
    {0x36, 0x49, 0x49, 0x49, 0x36}, // 8
    {0x06, 0x49, 0x49, 0x29, 0x1e}, // 9
    {0x00, 0x36, 0x36, 0x00, 0x00}, // :
    {0x00, 0x56, 0x36, 0x00, 0x00}, // ;
    {0x08, 0x14, 0x22, 0x41, 0x00}, // <
    {0x14, 0x14, 0x14, 0x14, 0x14}, // =
    {0x00, 0x41, 0x22, 0x14, 0x08}, // >
    {0x02, 0x01, 0x51, 0x09, 0x06}, // ?
    {0x32, 0x49, 0x79, 0x41, 0x3e}, // @
    {0x7e, 0x11, 0x11, 0x11, 0x7e}, // A
    {0x7f, 0x49, 0x49, 0x49, 0x36}, // B
    {0x3e, 0x41, 0x41, 0x41, 0x22}, // C
    {0x7f, 0x41, 0x41, 0x22, 0x1c}, // D
    {0x7f, 0x49, 0x49, 0x49, 0x41}, // E
    {0x7f, 0x09, 0x09, 0x09, 0x01}, // F
    {0x3e, 0x41, 0x49, 0x49, 0x7a}, // G
    {0x7f, 0x08, 0x08, 0x08, 0x7f}, // H
    {0x00, 0x41, 0x7f, 0x41, 0x00}, // I
    {0x20, 0x40, 0x41, 0x3f, 0x01}, // J
    {0x7f, 0x08, 0x14, 0x22, 0x41}, // K
    {0x7f, 0x40, 0x40, 0x40, 0x40}, // L
    {0x7f, 0x02, 0x0c, 0x02, 0x7f}, // M
    {0x7f, 0x04, 0x08, 0x10, 0x7f}, // N
    {0x3e, 0x41, 0x41, 0x41, 0x3e}, // O
    {0x7f, 0x09, 0x09, 0x09, 0x06}, // P
    {0x3e, 0x41, 0x51, 0x21, 0x5e}, // Q
    {0x7f, 0x09, 0x19, 0x29, 0x46}, // R
    {0x46, 0x49, 0x49, 0x49, 0x31}, // S
    {0x01, 0x01, 0x7f, 0x01, 0x01}, // T
    {0x3f, 0x40, 0x40, 0x40, 0x3f}, // U
    {0x1f, 0x20, 0x40, 0x20, 0x1f}, // V
    {0x3f, 0x40, 0x38, 0x40, 0x3f}, // W
    {0x63, 0x14, 0x08, 0x14, 0x63}, // X
    {0x07, 0x08, 0x70, 0x08, 0x07}, // Y
    {0x61, 0x51, 0x49, 0x45, 0x43}, // Z
    {0x00, 0x7f, 0x41, 0x41, 0x00}, // [
    {0x02, 0x04, 0x08, 0x10, 0x20},
    {0x00, 0x41, 0x41, 0x7f, 0x00}, // ]
    {0x04, 0x02, 0x01, 0x02, 0x04}, // ^
    {0x40, 0x40, 0x40, 0x40, 0x40}, // _
    {0x00, 0x01, 0x02, 0x04, 0x00}, // `
    {0x20, 0x54, 0x54, 0x54, 0x78}, // a
    {0x7f, 0x48, 0x44, 0x44, 0x38}, // b
    {0x38, 0x44, 0x44, 0x44, 0x20}, // c
    {0x38, 0x44, 0x44, 0x48, 0x7f}, // d
    {0x38, 0x54, 0x54, 0x54, 0x18}, // e
    {0x08, 0x7e, 0x09, 0x01, 0x02}, // f
    {0x0c, 0x52, 0x52, 0x52, 0x3e}, // g
    {0x7f, 0x08, 0x04, 0x04, 0x78}, // h
    {0x00, 0x44, 0x7d, 0x40, 0x00}, // i
    {0x20, 0x40, 0x44, 0x3d, 0x00}, // j
    {0x7f, 0x10, 0x28, 0x44, 0x00}, // k
    {0x00, 0x41, 0x7f, 0x40, 0x00}, // l
    {0x7c, 0x04, 0x18, 0x04, 0x78}, // m
    {0x7c, 0x08, 0x04, 0x04, 0x78}, // n
    {0x38, 0x44, 0x44, 0x44, 0x38}, // o
    {0x7c, 0x14, 0x14, 0x14, 0x08}, // p
    {0x08, 0x14, 0x14, 0x18, 0x7c}, // q
    {0x7c, 0x08, 0x04, 0x04, 0x08}, // r
    {0x48, 0x54, 0x54, 0x54, 0x20}, // s
    {0x04, 0x3f, 0x44, 0x40, 0x20}, // t
    {0x3c, 0x40, 0x40, 0x20, 0x7c}, // u
    {0x1c, 0x20, 0x40, 0x20, 0x1c}, // v
    {0x3c, 0x40, 0x30, 0x40, 0x3c}, // w
    {0x44, 0x28, 0x10, 0x28, 0x44}, // x
    {0x0c, 0x50, 0x50, 0x50, 0x3c}, // y
    {0x44, 0x64, 0x54, 0x4c, 0x44}, // z
    {0x00, 0x08, 0x36, 0x41, 0x00}, // {
    {0x00, 0x00, 0x7f, 0x00, 0x00}, // |
    {0x00, 0x41, 0x36, 0x08, 0x00}, // }
    {0x10, 0x08, 0x10, 0x08, 0x00}  // ~
};
/* --- 1. ALT SEVİYE DONANIM HABERLEŞME FONKSİYONLARI --- */
// Bu fonksiyonlar her zaman en üstte olmalıdır!

static void TFT_WriteCommand(uint8_t cmd) {
    HAL_GPIO_WritePin(TFT_RS_PORT, TFT_RS_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_RESET);

    TFT_DATA_PORT->ODR = (TFT_DATA_PORT->ODR & 0xFF00) | cmd;

    HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_SET);

    HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_SET);
}

static void TFT_WriteData(uint8_t data) {
    HAL_GPIO_WritePin(TFT_RS_PORT, TFT_RS_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_RESET);

    TFT_DATA_PORT->ODR = (TFT_DATA_PORT->ODR & 0xFF00) | data;

    HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_SET);

    HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_SET);
}

/* --- 2. GRAFİK ÇİZİM FONKSİYONLARI --- */
// Alt seviye fonksiyonları kullandıkları için onların altında yer alırlar

static void TFT_WriteData16(uint16_t data) {
    TFT_WriteData((data >> 8) & 0xFF);
    TFT_WriteData(data & 0xFF);
}

static void TFT_SetWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2) {
    TFT_WriteCommand(0x2A);
    TFT_WriteData16(x1);
    TFT_WriteData16(x2);
    TFT_WriteCommand(0x2B);
    TFT_WriteData16(y1);
    TFT_WriteData16(y2);
    TFT_WriteCommand(0x2C);
}

static void TFT_DrawPixel(uint16_t x, uint16_t y, uint16_t color) {
    TFT_SetWindow(x, y, x, y);
    TFT_WriteData16(color);
}

static void TFT_FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color) {
    uint32_t pixels = w * h;
    TFT_SetWindow(x, y, x + w - 1, y + h - 1);

    HAL_GPIO_WritePin(TFT_RS_PORT, TFT_RS_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_RESET);

    for (uint32_t i = 0; i < pixels; i++) {
        TFT_DATA_PORT->ODR = (TFT_DATA_PORT->ODR & 0xFF00) | ((color >> 8) & 0xFF);
        HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_SET);

        TFT_DATA_PORT->ODR = (TFT_DATA_PORT->ODR & 0xFF00) | (color & 0xFF);
        HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_SET);
    }
    HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_SET);
}

static void TFT_DrawChar(uint16_t x, uint16_t y, char c, uint16_t color, uint16_t bg, uint8_t size) {
    if (c < 32 || c > 126) return;

    for (uint8_t i = 0; i < 5; i++) {
        uint8_t line = font5x7[c - 32][i];
        for (uint8_t j = 0; j < 8; j++) {
            if (line & 0x1) {
                if (size == 1) TFT_DrawPixel(x + i, y + j, color);
                else TFT_FillRect(x + (i * size), y + (j * size), size, size, color);
            } else if (bg != color) {
                if (size == 1) TFT_DrawPixel(x + i, y + j, bg);
                else TFT_FillRect(x + (i * size), y + (j * size), size, size, bg);
            }
            line >>= 1;
        }
    }
}

static void TFT_DrawText(uint16_t x, uint16_t y, const char *str, uint16_t color, uint16_t bg, uint8_t size) {
    uint16_t cursor_x = x;
    while (*str) {
        TFT_DrawChar(cursor_x, y, *str, color, bg, size);
        cursor_x += 6 * size;
        str++;
    }
}
void Dashboard_Init(void) {
    // --- MANTIK HATASININ ÇÖZÜMÜ: VERİYOLU ÇAKIŞMASINI ÖNLE ---
    // Ekranla haberleşmeye başlamadan önce tüm kontrol pinlerini IDLE (HIGH) moduna alıyoruz!
    HAL_GPIO_WritePin(TFT_RD_PORT, TFT_RD_PIN, GPIO_PIN_SET); // Oku (Read) pinini kapat! Ekrana susmasını söyler.
    HAL_GPIO_WritePin(TFT_WR_PORT, TFT_WR_PIN, GPIO_PIN_SET); // Yaz (Write) pinini varsayılan duruma getir.
    HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_SET); // Çip seçimini boşa al.

    // Arka plan ışıklarını aç
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);

    // TFT Reset Sekansı (Eski kodun buradan itibaren aynen devam edecek)
    HAL_GPIO_WritePin(TFT_RST_PORT, TFT_RST_PIN, GPIO_PIN_SET);
    HAL_Delay(10);
    HAL_GPIO_WritePin(TFT_RST_PORT, TFT_RST_PIN, GPIO_PIN_RESET);
    HAL_Delay(10);
    HAL_GPIO_WritePin(TFT_RST_PORT, TFT_RST_PIN, GPIO_PIN_SET);
    HAL_Delay(120);

    // ILI9341 Standart Başlatma (Init) Sekansı
    TFT_WriteCommand(0x01); // Software Reset
    HAL_Delay(100);

    TFT_WriteCommand(0x11); // Sleep Out
    HAL_Delay(100);

    TFT_WriteCommand(0x3A); // Pixel Format Set
    TFT_WriteData(0x55);    // 16-bit RGB565

    TFT_WriteCommand(0x36); // Memory Access Control
    TFT_WriteData(0x28);    // Landscape (Yatay) mod

    TFT_WriteCommand(0x29); // Display ON
    HAL_Delay(100);

    // Ekranı temizle (Koyu Mavi Arka Plan)
    TFT_FillRect(0, 0, 320, 240, TFT_BG_COLOR);

    // Başlık Yazdır
    TFT_DrawText(10, 10, "STM32 SICAKLIK DASHBOARD", TFT_YELLOW, TFT_BG_COLOR, 2);
    // Altı çizili şerit
    TFT_FillRect(10, 30, 300, 2, TFT_WHITE);
}

void Dashboard_UpdateValues(float current, float min, float max, float avg) {
    char buffer[32];

    // Değerleri eski yazının üzerine bindirmemek için arka plan rengiyle (TFT_BG_COLOR) yazdırıyoruz
    sprintf(buffer, "Anlik Sicaklik: %.1f C ", current);
    TFT_DrawText(20, 60, buffer, TFT_WHITE, TFT_BG_COLOR, 2);

    sprintf(buffer, "Minimum Temp:   %.1f C ", min);
    TFT_DrawText(20, 100, buffer, TFT_GREEN, TFT_BG_COLOR, 2);

    sprintf(buffer, "Maksimum Temp:  %.1f C ", max);
    TFT_DrawText(20, 140, buffer, TFT_RED, TFT_BG_COLOR, 2);

    sprintf(buffer, "Ortalama Temp:  %.1f C ", avg);
    TFT_DrawText(20, 180, buffer, TFT_YELLOW, TFT_BG_COLOR, 2);
}

void Dashboard_ShowAlarm(void) {
    // Ekranın en altına kırmızı bir alarm kutusu çiz
    TFT_FillRect(20, 210, 280, 25, TFT_RED);
    TFT_DrawText(50, 215, "! DIKKAT YUKSEK SICAKLIK !", TFT_WHITE, TFT_RED, 1);
}

void Dashboard_ClearAlarm(void) {
    // Alarm durumundan çıkılınca o bölgeyi arka plan rengiyle boyayarak sil
    TFT_FillRect(20, 210, 280, 25, TFT_BG_COLOR);
}
